from django.db import models
from django.contrib.auth.models import AbstractUser


# Create your models here.
class User(AbstractUser):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(primary_key=True)
    date_of_birth = models.CharField(max_length=100)
    password = models.CharField(max_length=100)

class Student(User):
    level_of_study = models.CharField(max_length=100)
    num_of_sessions = models.IntegerField()
    num_of_weekly_sessions = models.IntegerField()

class Tutor(User):
    degree = models.CharField(max_length=100)
    field_of_expertise = models.CharField(max_length=100)
    num_of_tutoring_sessions = models.IntegerField()
    rating = models.DecimalField(max_digits=2, decimal_places=2)
    recommendations = models.CharField(max_length=2000)
    availability = models.CharField(max_length=200)

class Course():
    tutor_Id = models.ForeignKey(Tutor, on_delete=models.CASCADE)
    id = models.AutoField(primary_key=True) 
    duration = models.CharField(max_length=100)
    time = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    field = models.CharField(max_length=100)
    title = models.CharField(max_length=100)
    