from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf.urls import url
from core import views
from agora.views import Agora


urlpatterns = [
    url(r'^$', views.home, name="home"),
    url(r'^signin/$', views.signin, name="signin"),
    url(r'^signout/$', views.signout, name="signout"),
    url(r'^sessions/$', views.sessions, name="sessions"),
    url(r'^admin_page/$', views.admin_page, name="admin_page"),
    url(r'^add_tutor/$', views.add_tutor, name="add_tutor"),
    url(r'^add_student/$', views.add_student, name="add_student"),
    url(r'^edit_tutor/$', views.edit_tutor, name="edit_tutor"),
    url(r'^edit_student/$', views.edit_student, name="edit_student"),
    url(r'^tutors_home/$', views.tutors_home, name="tutors_home"),
    url(r'^contactus/$', views.contactus, name="contactus"),
    url(r'^request_session_token/(?P<tutor_email>.*)', views.request_session_token, name="request_session_token"),
    url(r'^agora/',Agora.as_view(
                                app_id='c36a81603cab4a31b4d93ecf9fd26e74',
                                channel='12'
                                )),
   ]
urlpatterns += staticfiles_urlpatterns()