from django.shortcuts import render, redirect, reverse, HttpResponseRedirect
from core.models import Tutor, Student
import firebase_admin
from firebase_admin import credentials, firestore, db
import os
from django.conf import settings
import pyrebase
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_protect
from django.contrib import messages
from django.core.mail import send_mail

# Create your views here.
def get_auth():
    firebaseConfig = {
            'apiKey': "AIzaSyAg1A1R09ZcnLsa7CTmWj-Xk9CxQyPMsmY",
            'authDomain': "guideme-96a97.firebaseapp.com",
            'databaseURL': "https://guideme-96a97.firebaseio.com",
            'projectId': "guideme-96a97",
            'storageBucket': "guideme-96a97.appspot.com",
            'messagingSenderId': "1097740063012",
            'appId': "1:1097740063012:web:966b1ea13a1625debba3b1",
            'measurementId': "G-1XB92JX2YJ"
        }
    firebaseApp = pyrebase.initialize_app(firebaseConfig)
    return firebaseApp.auth()

def home(request):
    return render(request,'index.html')

def signout(request):
    request.session.clear()
    return HttpResponseRedirect(reverse('home'))
    
@csrf_protect
def signin(request):
    if request.POST:
        email = ''
        password = ''
        user_type = ''
        auth = get_auth()
        if 'email' in request.POST:
            email = request.POST['email']
        if 'pass' in request.POST:
            password = request.POST['pass']

        if 'user_type' in request.POST:
            user_type = request.POST['user_type']  
        try:
            user = auth.sign_in_with_email_and_password(email,password)
            request.session['email'] = email
            path = os.path.join(settings.STATIC_ROOT, 'guideme-96a97-firebase-adminsdk-5csc9-8f71b315b0.json')
            
            if not firebase_admin._apps:
                cred = credentials.Certificate(path)
                app = firebase_admin.initialize_app(cred)
            db = firestore.client()
            ref =  db.collection(user_type)
            found = False
            for i in (ref.list_documents()):
                item = i.get().to_dict()
                if email == item['email']:
                    request.session[user_type] = user_type
                    found = True
                    if  user_type  == 'Student':
                        return HttpResponseRedirect(reverse('tutors_home'))
                    elif user_type == 'Tutor':
                        return HttpResponseRedirect(reverse('sessions'))                    
                    elif user_type == 'Admin':
                        return HttpResponseRedirect(reverse('admin_page'))
                    else:
                        messages.success(request, 'Choose the correct user type')
                        return HttpResponseRedirect(reverse('signin'))
            if not found:
                messages.success(request, 'Email not found in this user type')
                return HttpResponseRedirect(reverse('signin'))
        except:
            messages.success(request, 'PASSWORD AND EMAIL DONT MATCH')
            return HttpResponseRedirect(reverse('signin'))
    else:
        return render(request, 'signin.html')


def sessions(request):
    email = 'email'
    student = ''
    if 'Student' in request.session:
        student = 'Student'
    if email in request.session:
        return render(request,'sessions.html', {'email':email, 'student':student})
    else:
        messages.success(request, 'You are not signed in')
        return HttpResponseRedirect(reverse('signin'))


def get_tutors():
    path = os.path.join(settings.STATIC_ROOT, 'guideme-96a97-firebase-adminsdk-5csc9-8f71b315b0.json')
    # add to db
    if not firebase_admin._apps:
        cred = credentials.Certificate(path)
        app = firebase_admin.initialize_app(cred)
    db = firestore.client()
    
    ref =  db.collection('Tutor')
    
    tutors = []
    for i in (ref.list_documents()):
        item = i.get().to_dict()
        t = Tutor()
        if 'email' in item.keys():
            t.email = item['email']
        if 'date_of_birth' in item.keys():
            t.date_of_birth = item['date_of_birth']
        if 'degree' in item.keys():
            t.degree = item['degree']
        if 'field_of_expertise' in item.keys():
            t.field_of_expertise = item['field_of_expertise']
        if 'first_name' in item.keys():
            t.first_name = item['first_name'] 
        if 'last_name' in item.keys():
            t.last_name = item['last_name']
        if 'num_of_tutoring_sessions' in item.keys():
            t.num_of_tutoring_sessions = item['num_of_tutoring_sessions']
        if 'rating' in item.keys():
            t.rating = item['rating']
        if 'recommendations' in item.keys():
            t.recommendations = item['recommendations']
        if 'availability' in item.keys():
            t.availability = item['availability']
        # phone ====================
        if 'phone_number' in item.keys():
            t.phone_number = item['phone_number']
        #       ======================== 
        tutors.append(t)
    return tutors

def get_students():
    path = os.path.join(settings.STATIC_ROOT, 'guideme-96a97-firebase-adminsdk-5csc9-8f71b315b0.json')
    # add to db
    if not firebase_admin._apps:
        cred = credentials.Certificate(path)
        app = firebase_admin.initialize_app(cred)
    db = firestore.client()
    
    ref =  db.collection('Student')
    
    students = []
    for i in (ref.list_documents()):
        item = i.get().to_dict()
        s = Student()
        if 'email' in item.keys():
            s.email = item['email']
        if 'date_of_birth' in item.keys():
            s.date_of_birth = item['date_of_birth']
        if 'first_name' in item.keys():
            s.first_name = item['first_name'] 
        if 'last_name' in item.keys():
            s.last_name = item['last_name']
        if 'num_of_sessions' in item.keys():
            s.num_of_sessions = item['num_of_sessions']
        if 'level_of_study' in item.keys():
            s.level_of_study = item['level_of_study']
        if 'phone_number' in item.keys():
            s.phone_number = item['phone_number']
        students.append(s)
    return students

def admin_page(request):
    if 'Admin' in request.session.keys(): 
        tutors = get_tutors()
        students =  get_students()
        return render(request,'admin_page.html', context={'tutors':tutors, 'students':students})
    else:
        messages.success(request, 'YOU ARE NOT ALLOWED HERE, YOU MUST LOGIN AS AN ADMIN')
        return render(request, 'signin.html')
@csrf_protect
def add_tutor(request):

    if request.POST:
        path = os.path.join(settings.STATIC_ROOT, 'guideme-96a97-firebase-adminsdk-5csc9-8f71b315b0.json')
        email = request.POST['email']
        if not firebase_admin._apps:
        
            cred = credentials.Certificate(path)
            app = firebase_admin.initialize_app(cred)
        db = firestore.client()
        doc_ref =  db.collection('Tutor')
        
        exist = doc_ref.document(email).get().exists
        if not exist:
            try:
                doc_ref.document(email).set({
                    u'first_name':request.POST['fname'],
                    u'last_name':request.POST['lname'],
                    u'field_of_expertise':request.POST['field_of_expertise'],
                    u'email': email,
                    u'degree':request.POST['degree'],
                    u'date_of_birth':request.POST['date_of_birth'],
                    u'rating':0,
                    u'num_of_tutoring_sessions':0,
                    u'recommendations':str([]),
                    u'password':request.POST['password'],
                    u'availability':request.POST['availability'],
                    u'phone_number':request.POST['phone_number'],
                    u'countRate':1,
                    u'totalRate':5,

                }, merge=True)
                auth = get_auth()
                user = auth.create_user_with_email_and_password(request.POST['email'], request.POST['password'])
            
            except:
                messages.success(request, 'Record is not Added check the validaity of the fields')    
        else:
            messages.success(request, 'Email Exists')    
    return HttpResponseRedirect(reverse('admin_page'))

@csrf_protect
def add_student(request):
    if request.POST:
        path = os.path.join(settings.STATIC_ROOT, 'guideme-96a97-firebase-adminsdk-5csc9-8f71b315b0.json')
        email = request.POST['email']
        if not firebase_admin._apps:
            cred = credentials.Certificate(path)
            app = firebase_admin.initialize_app(cred)
       
        db = firestore.client()
        doc_ref =  db.collection('Student')
        
        exist = doc_ref.document(email).get().exists
        if not exist:
            try:
                doc_ref.document(email).set({
                    u'first_name':request.POST['fname'],
                    u'last_name':request.POST['lname'],
                    u'email': email,
                    u'date_of_birth':request.POST['date_of_birth'],
                    u'level_of_study':request.POST['level_of_study'],
                    u'num_of_weekly_sessions':0,
                    u'num_of_sessions':0,
                    u'password':request.POST['password'],
                    u'phone_number':request.POST['phone_number'],

                }, merge=True)
                auth = get_auth()
                auth.create_user_with_email_and_password(request.POST['email'], request.POST['password'])
            except:
                messages.success(request, 'Record is not Added check the validaity of the fields')    
        else:
            messages.success(request, 'Email Exists')    
    return HttpResponseRedirect(reverse('admin_page'))

@csrf_protect
def edit_tutor(request):

    if request.POST:
        path = os.path.join(settings.STATIC_ROOT, 'guideme-96a97-firebase-adminsdk-5csc9-8f71b315b0.json')
        email = request.POST['email']
        # add to db
        if not firebase_admin._apps:
            cred = credentials.Certificate(path)
            app = firebase_admin.initialize_app(cred)
        db = firestore.client()
        doc_ref =  db.collection('Tutor')
        try:
            doc_ref.document(email).update({
                u'first_name':request.POST['fname'],
                u'last_name':request.POST['lname'],
                u'field_of_expertise':request.POST['field_of_expertise'],
                u'email': email,
                u'degree':request.POST['degree'],
                u'date_of_birth':request.POST['date_of_birth'],
                u'rating':0,
                u'num_of_tutoring_sessions':0,
                u'recommendations':str([]),
                u'password':request.POST['password'],
                u'availability':request.POST['availability'],
                u'phone_number':request.POST['phone_number'],
            })
        except:
            messages.success(request, 'Record is not Added check the validaity of the fields')    
     
    return HttpResponseRedirect(reverse('admin_page'))

@csrf_protect
def edit_student(request):
    if request.POST:
        path = os.path.join(settings.STATIC_ROOT, 'guideme-96a97-firebase-adminsdk-5csc9-8f71b315b0.json')
        email = request.POST['email']
        # add to db
        if not firebase_admin._apps:
            cred = credentials.Certificate(path)
            app = firebase_admin.initialize_app(cred)
       
        db = firestore.client()
        doc_ref =  db.collection('Student')

        try:
            doc_ref.document(email).update({
                u'first_name':request.POST['fname'],
                u'last_name':request.POST['lname'],
                u'email': email,
                u'date_of_birth':request.POST['date_of_birth'],
                u'level_of_study':request.POST['level_of_study'],
                u'num_of_weekly_sessions':0,
                u'num_of_sessions':0,
                u'password':request.POST['password'],            
                u'phone_number':request.POST['phone_number'],

            })
        except:
            messages.success(request, 'Record is not Added check the validaity of the fields')    

    return HttpResponseRedirect(reverse('admin_page'))

def tutors_home(request):
    tutors = get_tutors()
    return render(request, 'tutors_home.html', context={'tutors':tutors})


def request_session_token(request, tutor_email):
    if not firebase_admin._apps:
        path = os.path.join(settings.STATIC_ROOT, 'guideme-96a97-firebase-adminsdk-5csc9-8f71b315b0.json')
        cred = credentials.Certificate(path)
        app = firebase_admin.initialize_app(cred)
    
    email = request.session['email']   
    db = firestore.client()
    ref =  db.collection('Student')
    list_of_weekly_sessions = ref.document(email).get({
                u'num_of_weekly_sessions'
            })
    num_of_weekly_sessions = list_of_weekly_sessions.get('num_of_weekly_sessions')     
        
    
    if (int (num_of_weekly_sessions) < 2):
            # ref.document(email).update({
            #     u'num_of_weekly_sessions':str(num_of_weekly_sessions + 1),
            # })
            send_mail(
                'Session Token',
                'Dear Tutor, \n I would like to attend your session, please send me the channel token on this email "' + user_email +'" . \n best,',
                'guidemeemail@gmail.com',
                [tutor_email],
                fail_silently=False
            )
            messages.success(request, 'Email sent!')
            return HttpResponseRedirect(reverse('tutors_home'))
    else:
        messages.success(request, 'You Exceeded Your Maximum Weekly Limit for sessions')
        return HttpResponseRedirect(reverse('tutors_home'))

def rate(request, tutor_email):
    if request.POST:
        print("sefjoes")
    else:
        print('dhgjk')
    return HttpResponseRedirect(reverse('tutors_home'))
def contactus(request):
    email ='NONE'
    name ='NONE'
    subject ='NONE'
    message = 'NONE'
    if request.POST and ('email' in request.POST.keys()):
        email = request.POST['email']
        if 'name' in request.POST.keys():
            name = request.POST['name']
        if 'subject' in request.POST.keys():
            subject = request.POST['subject']
        if 'message' in request.POST.keys():
            message = request.POST['message']        
            
            send_mail(
                subject+' from '+ email,
                name + '\n' + message,
                'guidemeemail@gmail.com',
                ['guidemeemail@gmail.com'],
                fail_silently=False
            )
            
        messages.success(request, 'Email sent!')
        return render(request,'index.html')
    else:
        messages.success(request, 'You ARE NOT LOGGED IN')
        return HttpResponseRedirect(reverse('home'))
        
def edit_times(request):
    if request.POST:
        email = request.session['email']
        path = os.path.join(settings.STATIC_ROOT, 'guideme-96a97-firebase-adminsdk-5csc9-8f71b315b0.json')
        if not firebase_admin._apps:
            cred = credentials.Certificate(path)
            app = firebase_admin.initialize_app(cred)
       
        db = firestore.client()
        doc_ref =  db.collection('Tutor')

        try:
            doc_ref.document(email).update({
                u'availability':request.POST['edit_t'],
            })
        except:
            messages.success(request, 'Record is not Added check the validaity of the fields')    
        
    return HttpResponseRedirect(reverse('sessions'))
